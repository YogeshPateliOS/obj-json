//
//  webservices.h
//  Obj json
//
//  Created by Yogesh Patel on 14/11/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface webservices : NSObject
+(void)executequery:(NSString *)strurl strpremeter:(NSString *)perameter withblock:(void(^)(NSData *, NSError *))block;
@end
