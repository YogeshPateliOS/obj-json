//
//  webservices.m
//  Obj json
//
//  Created by Yogesh Patel on 14/11/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import "webservices.h"

@implementation webservices
+(void)executequery:(NSString *)strurl strpremeter:(NSString *)perameter withblock:(void (^)(NSData *, NSError *))block
{
    NSURLSessionConfiguration *defaultconfigartion = [NSURLSessionConfiguration defaultSessionConfiguration];
    NSURLSession *urlsession = [NSURLSession sessionWithConfiguration:defaultconfigartion delegate:nil delegateQueue:[NSOperationQueue mainQueue]];
    
    NSURL *url =[NSURL URLWithString:strurl];
    NSMutableURLRequest *urlrequest = [NSMutableURLRequest requestWithURL:url];
    
    NSString *strmain = perameter;
    [urlrequest setHTTPMethod:@"GET"];
    [urlrequest setHTTPBody:[strmain dataUsingEncoding:NSUTF8StringEncoding]];
    
    
    NSURLSessionDataTask *datatask = [urlsession dataTaskWithRequest:urlrequest completionHandler:^(NSData *  data, NSURLResponse *  response, NSError *  error) {
        if (data != nil)
        {
            NSLog(@"Response Data: %@",data);
            block(data, error);
        }
        else
        {
            NSLog(@"Error");
            block(nil,error);
        }
    }];
  [datatask resume];
}
@end
