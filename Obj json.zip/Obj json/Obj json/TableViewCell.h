//
//  TableViewCell.h
//  Obj json
//
//  Created by Yogesh Patel on 14/11/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableViewCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *lblname;
@property (strong, nonatomic) IBOutlet UILabel *lbladdress;
@property (strong, nonatomic) IBOutlet UILabel *lblemail;
@property (strong, nonatomic) IBOutlet UILabel *lblid;
@property (strong, nonatomic) IBOutlet UILabel *lblhome;

@property (strong, nonatomic) IBOutlet UILabel *lblgender;
@property (strong, nonatomic) IBOutlet UILabel *lbloffice;
@property (strong, nonatomic) IBOutlet UILabel *lblmobile;





@end
