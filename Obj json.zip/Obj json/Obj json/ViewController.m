//
//  ViewController.m
//  Obj json
//
//  Created by Yogesh Patel on 14/11/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import "ViewController.h"
#import "webservices.h"
#import "TableViewCell.h"
@interface ViewController ()
{
    NSString * mainstr;
    NSMutableArray *armain;
    NSMutableArray * arraddress, *arremail, *arrgender, *arrid, *arrname, *arroffice, *arrmobile, *arrhome;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self copyandpaste];
    armain = [[NSMutableArray alloc]initWithObjects:@"sfsdf",@"sfsdf",@"sfsdf",@"sfsdf",@"sfsdf",@"sfsdf",@"sfsdf",@"sfsdf", nil];
    // Do any additional setup after loading the view, typically from a nib.
}

-(void)copyandpaste
{
    mainstr = [NSString stringWithFormat:@"https://api.androidhive.info/contacts/"];
//    NSString *dbstr = [NSString stringWithFormat:@"Name=Yogesh&Mobile=9712271041&DOB=1995/12/21&Address=Meghaninagar,Ahmedabad"];
    [webservices executequery:mainstr strpremeter:nil withblock:^(NSData *dbdata, NSError *error) {
        
        
        NSLog(@"data:%@",dbdata);
      
        if (dbdata != nil) {
            
        
        NSDictionary *maindic = [NSJSONSerialization JSONObjectWithData:dbdata options:NSJSONReadingAllowFragments error:nil];
        NSLog(@"Response Data: %@",maindic);
            
            
            NSDictionary *dic1 = [maindic objectForKey:@"contacts"];
            arraddress = [[NSMutableArray alloc]init];
            arremail = [[NSMutableArray alloc]init];
            arrgender = [[NSMutableArray alloc]init];
            arrid = [[NSMutableArray alloc]init];
            arrname = [[NSMutableArray alloc]init];
            arroffice = [[NSMutableArray alloc]init];
            arrmobile = [[NSMutableArray alloc]init];
            arrhome = [[NSMutableArray alloc]init];
            for (NSDictionary *dic in dic1)
            {
                NSString *straddress = [dic objectForKey:@"address"];
                [arraddress addObject:straddress];
                
                NSString *stremail = [dic objectForKey:@"email"];
                [arremail addObject:stremail];
                
                NSString *strgender = [dic objectForKey:@"gender"];
                [arrgender addObject:strgender];
                
                NSString *strid = [dic objectForKey:@"id"];
                [arrid addObject:straddress];
                
                NSString *strname = [dic objectForKey:@"name"];
                [arrname addObject:straddress];
                
                NSDictionary *dic2 = [dic objectForKey:@"phone"];
                
                NSString *stroffice = [dic2 objectForKey:@"office"];
                [arroffice addObject:stroffice];
                NSString *stroffice1 = [dic2 objectForKey:@"mobile"];
                [arrmobile addObject:stroffice1];
                NSString *stroffice2 = [dic2 objectForKey:@"home"];
                [arrhome addObject:stroffice2];
            }
        }
        [self.tblview reloadData];
    }];
    
    
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return  arraddress.count;
    
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    TableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (cell == nil)
    {
        cell = [[TableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
   // cell.textLabel.text = armain[indexPath.row];
    cell.lbladdress.text = arraddress[indexPath.row];
     cell.lblemail.text = arremail[indexPath.row];
    cell.lblgender.text = arrgender[indexPath.row];
     cell.lblid.text = arrid[indexPath.row];
   cell.lblname.text = arrname[indexPath.row];
   
    cell.lbloffice.text = arroffice[indexPath.row];
    
    cell.lblmobile.text = arrmobile[indexPath.row];
   
    cell.lblhome.text = arrhome[indexPath.row];
    
    
    return  cell;
}
@end
